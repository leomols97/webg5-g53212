package chap20.internationalisation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternationalisationApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternationalisationApplication.class, args);
	}

}
