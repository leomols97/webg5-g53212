package chap20.internationalisation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternationalisationApplicationTests {

	@Test
	void contextLoads() {
	}

}
