package Chap15.jpa.DB.dto;

public enum Section {
    INDUSTRIEL,
    RESEAUX,
    GESTION
}