package Chap15.jpa.DB.dto;

public enum Genre {
    M,
    F
}
