package com.example.pae;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaeApplicationTests {

	@Test
	void contextLoads() {
	}

}
